#!/bin/bash
if [ $# -ne 1 ]; then
    echo "Please specify name of results file which contains table to be expanded with private data "
    exit
fi
results_file_with_table=$1
sed -i 's/<td> A__J <\/td>/<td>  A__J  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> Alain1965 <\/td>/<td>  Alain1965  <\/td><td>  Alain  <\/td><td>  Sienaert  <\/td><td>  1965  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> anatolij <\/td>/<td>  anatolij  <\/td><td>  alessio  <\/td><td>  saviane  <\/td><td>  1976  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> audax <\/td>/<td>  audax  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> BigRing2010 <\/td>/<td>  BigRing2010  <\/td><td>  Steve  <\/td><td>  Larsen  <\/td><td>  1968  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> breers33 <\/td>/<td>  breers33  <\/td><td>  Brian  <\/td><td>  Ward  <\/td><td>  1980  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> Carlos64_GURE <\/td>/<td>  Carlos64_GURE  <\/td><td>  Carlos  <\/td><td>  Ariño  <\/td><td>  1964  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> cervelos5p3 <\/td>/<td>  cervelos5p3  <\/td><td>  Rick  <\/td><td>  Smith  <\/td><td>  1966  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> chrisleuty <\/td>/<td>  chrisleuty  <\/td><td>  Chris  <\/td><td>  Leuty  <\/td><td>  1966  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> ChristophKirsche <\/td>/<td>  ChristophKirsche  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> couch_tour <\/td>/<td>  couch_tour  <\/td><td>  Greg  <\/td><td>  Russell  <\/td><td>  1971  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> CPatterson <\/td>/<td>  CPatterson  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> Cyril_Gintonix_Michaud <\/td>/<td>  Cyril_Gintonix_Michaud  <\/td><td>  Cyril  <\/td><td>  Michaud  <\/td><td>  1972  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> dinx <\/td>/<td>  dinx  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> dmb_83 <\/td>/<td>  dmb_83  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> EdReich69 <\/td>/<td>  EdReich69  <\/td><td>  Edgar  <\/td><td>  Reichart  <\/td><td>  1969  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> metavug <\/td>/<td>  metavug  <\/td><td>  eric  <\/td><td>  winkler  <\/td><td>  1962  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> GAMER <\/td>/<td>  GAMER  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> gang_olsena <\/td>/<td>  gang_olsena  <\/td><td>  Krzysztof  <\/td><td>  Pilimon  <\/td><td>  1970  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> MikeHPLCycling <\/td>/<td>  MikeHPLCycling  <\/td><td>  Mike  <\/td><td>  Gavelis  <\/td><td>  1986  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> hacksau <\/td>/<td>  hacksau  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> HeikeHardt <\/td>/<td>  HeikeHardt  <\/td><td>  Heike  <\/td><td>  Hardt  <\/td><td>  1962  <\/td><td>  female  <\/td>/g'  $results_file_with_table
sed -i 's/<td> henrikt <\/td>/<td>  henrikt  <\/td><td>  Henrik  <\/td><td>  Tornøe  <\/td><td>  1960  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> pwilson151 <\/td>/<td>  pwilson151  <\/td><td>  Peter  <\/td><td>  Wilson  <\/td><td>  1961  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> JensMTB <\/td>/<td>  JensMTB  <\/td><td>  Jens  <\/td><td>  Christiansen  <\/td><td>  1966  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> joe_cool <\/td>/<td>  joe_cool  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> kingcon <\/td>/<td>  kingcon  <\/td><td>  Christophe  <\/td><td>  Odekerken  <\/td><td>  1973  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> KMaistrenko <\/td>/<td>  KMaistrenko  <\/td><td>  Kostiantyn  <\/td><td>  Maistrenko  <\/td><td>  1988  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> laurentc <\/td>/<td>  laurentc  <\/td><td>  Laurent  <\/td><td>  Cretegny  <\/td><td>  1972  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> macko <\/td>/<td>  macko  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> MARK_J <\/td>/<td>  MARK_J  <\/td><td>  Mark  <\/td><td>  Jones  <\/td><td>  1976  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> MatthiasHeil <\/td>/<td>  MatthiasHeil  <\/td><td>  Matthias  <\/td><td>  Heil  <\/td><td>  1965  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> Matti346 <\/td>/<td>  Matti346  <\/td><td>  Matt  <\/td><td>  Hellard  <\/td><td>  1971  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> purplebengal <\/td>/<td>  purplebengal  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> mikes-oh <\/td>/<td>  mikes-oh  <\/td><td>  Michael  <\/td><td>  Stoecker  <\/td><td>  1958  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> nigelhardy <\/td>/<td>  nigelhardy  <\/td><td>  Nigel  <\/td><td>  Hardy  <\/td><td>  1964  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> nvdb <\/td>/<td>  nvdb  <\/td><td>  Noël  <\/td><td>  Van den Brande  <\/td><td>  1965  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> DIE-Oma <\/td>/<td>  DIE-Oma  <\/td><td>  Christoph  <\/td><td>  Maier  <\/td><td>  1977  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> orthostice <\/td>/<td>  orthostice  <\/td><td>  Giovanni  <\/td><td>  Berti  <\/td><td>  1964  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> pesaari <\/td>/<td>  pesaari  <\/td><td>  Petteri  <\/td><td>  Saari  <\/td><td>  1968  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> Peter_69 <\/td>/<td>  Peter_69  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> petermreid <\/td>/<td>  petermreid  <\/td><td>  Peter  <\/td><td>  Reid  <\/td><td>  1969  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> Picchetti.Enrico <\/td>/<td>  Picchetti.Enrico  <\/td><td>  Enrico  <\/td><td>  Picchetti  <\/td><td>  1964  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> quicknik80 <\/td>/<td>  quicknik80  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> ridewithoutstomach <\/td>/<td>  ridewithoutstomach  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> Robbo_66 <\/td>/<td>  Robbo_66  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> robse3011 <\/td>/<td>  robse3011  <\/td><td>  Robert  <\/td><td>  Denzler  <\/td><td>  1970  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> El_Tractor <\/td>/<td>  El_Tractor  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> max_pushupz <\/td>/<td>  max_pushupz  <\/td><td>  Scott  <\/td><td>  Ahlgren  <\/td><td>  1969  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> scvwaal <\/td>/<td>  scvwaal  <\/td><td>  Steve  <\/td><td>  Vander Waal  <\/td><td>  1948  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> SeanMuzzy <\/td>/<td>  SeanMuzzy  <\/td><td>  Sean  <\/td><td>  Murray  <\/td><td>  1982  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> shanthi_is_not_on_rouvy <\/td>/<td>  shanthi_is_not_on_rouvy  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> spacecheese <\/td>/<td>  spacecheese  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> Stefan793 <\/td>/<td>  Stefan793  <\/td><td>  Stefan  <\/td><td>  Aumüller  <\/td><td>  1979  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> stfmgr_65 <\/td>/<td>  stfmgr_65  <\/td><td>  stefano  <\/td><td>  magrini  <\/td><td>  1965  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> Stig_F <\/td>/<td>  Stig_F  <\/td><td>  Stig  <\/td><td>  Flensborg  <\/td><td>  1964  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> SwissChris69 <\/td>/<td>  SwissChris69  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> tcwings <\/td>/<td>  tcwings  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> Thomson_Alive <\/td>/<td>  Thomson_Alive  <\/td><td>  Thomas  <\/td><td>  Kramer  <\/td><td>  1978  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td> tigostar <\/td>/<td>  tigostar  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td><td>  <small>--<\/small>  <\/td>/g'  $results_file_with_table
sed -i 's/<td> whitesheep <\/td>/<td>  whitesheep  <\/td><td>  Krispin  <\/td><td>  Hable  <\/td><td>  1980  <\/td><td>  male  <\/td>/g'  $results_file_with_table
sed -i 's/<td>Rouvy username<\/td>/<td>Rouvy username<\/td><td>First name<\/td><td>Surname<\/td><td>YOB<\/td><td>Gender<\/td>/g' $results_file_with_table
